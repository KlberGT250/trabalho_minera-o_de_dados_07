from contextlib import asynccontextmanager
from fastapi import FastAPI
import joblib
from app import router_modelos

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.modelo_regressao = joblib.load("app/modelos/modelo_regressao.pkl")

    yield
    del app.state.modelo_regressao


app = FastAPI(lifespan=lifespan)
app.include_router(router_modelos.router)


